(()=>{var e={};e.id=7667,e.ids=[7667],e.modules={72934:e=>{"use strict";e.exports=require("next/dist/client/components/action-async-storage.external.js")},54580:e=>{"use strict";e.exports=require("next/dist/client/components/request-async-storage.external.js")},45869:e=>{"use strict";e.exports=require("next/dist/client/components/static-generation-async-storage.external.js")},20399:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},78893:e=>{"use strict";e.exports=require("buffer")},84770:e=>{"use strict";e.exports=require("crypto")},17702:e=>{"use strict";e.exports=require("events")},98216:e=>{"use strict";e.exports=require("net")},35816:e=>{"use strict";e.exports=require("process")},76162:e=>{"use strict";e.exports=require("stream")},74026:e=>{"use strict";e.exports=require("string_decoder")},95346:e=>{"use strict";e.exports=require("timers")},82452:e=>{"use strict";e.exports=require("tls")},17360:e=>{"use strict";e.exports=require("url")},21764:e=>{"use strict";e.exports=require("util")},71568:e=>{"use strict";e.exports=require("zlib")},72254:e=>{"use strict";e.exports=require("node:buffer")},90029:(e,t,a)=>{"use strict";a.r(t),a.d(t,{GlobalError:()=>o.a,__next_app__:()=>g,originalPathname:()=>c,pages:()=>p,routeModule:()=>f,tree:()=>d}),a(62043),a(52187),a(24340),a(32029),a(35866);var i=a(23191),n=a(88716),r=a(37922),o=a.n(r),l=a(95231),s={};for(let e in l)0>["default","tree","pages","GlobalError","originalPathname","__next_app__","routeModule"].indexOf(e)&&(s[e]=()=>l[e]);a.d(t,s);let d=["",{children:["admin",{children:["settings",{children:["templates",{children:["__PAGE__",{},{page:[()=>Promise.resolve().then(a.bind(a,62043)),"C:\\github\\trakovo\\src\\app\\admin\\settings\\templates\\page.tsx"]}]},{}]},{layout:[()=>Promise.resolve().then(a.bind(a,52187)),"C:\\github\\trakovo\\src\\app\\admin\\settings\\layout.tsx"]}]},{layout:[()=>Promise.resolve().then(a.bind(a,24340)),"C:\\github\\trakovo\\src\\app\\admin\\layout.tsx"]}]},{layout:[()=>Promise.resolve().then(a.bind(a,32029)),"C:\\github\\trakovo\\src\\app\\layout.tsx"],"not-found":[()=>Promise.resolve().then(a.t.bind(a,35866,23)),"next/dist/client/components/not-found-error"]}],p=["C:\\github\\trakovo\\src\\app\\admin\\settings\\templates\\page.tsx"],c="/admin/settings/templates/page",g={require:a,loadChunk:()=>Promise.resolve()},f=new i.AppPageRouteModule({definition:{kind:n.x.APP_PAGE,page:"/admin/settings/templates/page",pathname:"/admin/settings/templates",bundlePath:"",filename:"",appPaths:[]},userland:{loaderTree:d}})},29754:(e,t,a)=>{Promise.resolve().then(a.bind(a,35955))},35303:()=>{},35955:(e,t,a)=>{"use strict";a.d(t,{default:()=>x});var i=a(10326),n=a(17577);let r=[{name:"booking_ref",description:"Booking reference (e.g. VHB-0042)"},{name:"vehicle_name",description:"Vehicle name"},{name:"hire_type",description:'"Chauffeured Hire" or "Dry Hire (Self-Drive)"'},{name:"start_date",description:"Start date"},{name:"end_date",description:"End date"},{name:"total_days",description:"Number of days"},{name:"daily_rate",description:"Daily rate (e.g. $450 AUD)"},{name:"total_cost",description:"Total cost (e.g. $1350 AUD)"},{name:"contact_name",description:"Contact or driver name"},{name:"contact_email",description:"Contact email"},{name:"contact_phone",description:"Contact phone"},{name:"driver_name",description:"Driver name (dry hire)"},{name:"driver_dob",description:"Driver date of birth"},{name:"driver_licence_number",description:"Driver licence number"},{name:"driver_licence_expiry",description:"Driver licence expiry"},{name:"site_name",description:"Site/business name"},{name:"site_url",description:"Site URL"},{name:"admin_url",description:"Admin bookings URL"},{name:"note",description:"Staff note (customer quote only)"},{name:"created_at",description:"Booking creation timestamp"}],o=[{name:"is_dry_hire",description:"Content shown only for dry-hire bookings"},{name:"is_chauffeured",description:"Content shown only for chauffeured bookings"},{name:"note",description:"Content shown only when a staff note is included"}];function l(e,t,a=!1){return`
      <tr style="border-bottom:1px solid #e8e6e0;">
        <td style="padding:11px 0;font-size:12px;color:#888;width:44%;text-transform:uppercase;letter-spacing:0.05em;font-weight:600;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;">${e}</td>
        <td style="padding:11px 0;font-size:${a?"16":"13.5"}px;color:${a?"#d4570a":"#1a1a1a"};font-weight:${a?"800":"600"};text-align:right;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;">${t}</td>
      </tr>`}new Date().toISOString();let s=`<!DOCTYPE html>
<html lang="en">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0"><title>New Booking {{booking_ref}}</title></head>
<body style="margin:0;padding:0;background:#f0efe9;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;">
  <table width="100%" cellpadding="0" cellspacing="0" style="background:#f0efe9;padding:40px 20px;">
    <tr><td align="center">
      <table width="600" cellpadding="0" cellspacing="0" style="background:#ffffff;border-radius:12px;overflow:hidden;border:1px solid #e2e0d8;">

        <tr>
          <td style="background:#1a2235;padding:28px 36px;">
            <table width="100%" cellpadding="0" cellspacing="0"><tr>
              <td>
                <span style="display:inline-block;background:#d4570a;color:#fff;font-weight:800;font-size:13px;padding:4px 8px;border-radius:4px;letter-spacing:0.05em;">A</span>
                <span style="color:#fff;font-weight:700;font-size:15px;margin-left:8px;vertical-align:middle;letter-spacing:-0.01em;">{{site_name}}</span>
                <p style="color:rgba(255,255,255,0.4);font-size:11px;margin:4px 0 0 0;text-transform:uppercase;letter-spacing:0.08em;">Admin Notification</p>
              </td>
              <td align="right">
                <p style="color:rgba(255,255,255,0.4);font-size:11px;margin:0;text-transform:uppercase;letter-spacing:0.08em;">New Booking Request</p>
                <p style="color:#d4570a;font-size:22px;font-weight:700;margin:4px 0 0 0;font-family:monospace;">{{booking_ref}}</p>
              </td>
            </tr></table>
          </td>
        </tr>

        <tr><td style="padding:32px 36px;">
          <p style="margin:0 0 24px;font-size:15px;color:#1a1a1a;">
            A new <strong>{{hire_type}}</strong> booking has been submitted for <strong>{{vehicle_name}}</strong>.
          </p>

          <table width="100%" cellpadding="0" cellspacing="0" style="background:#f7f6f2;border-radius:8px;margin-bottom:24px;overflow:hidden;border:1px solid #e2e0d8;">
            <tr><td style="padding:14px 18px;border-bottom:1px solid #e2e0d8;background:#f0efe9;">
              <p style="margin:0;font-size:10px;font-weight:700;color:#888;text-transform:uppercase;letter-spacing:0.1em;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;">Booking Summary</p>
            </td></tr>
            <tr><td style="padding:0 18px;">
              <table width="100%" cellpadding="0" cellspacing="0">${l("Booking Ref","{{booking_ref}}")}${l("Vehicle","{{vehicle_name}}")}${l("Hire Type","{{hire_type}}")}${l("Start Date","{{start_date}}")}${l("End Date","{{end_date}}")}${l("Duration","{{total_days}} days")}${l("Daily Rate","{{daily_rate}}")}${l("Estimated Total","{{total_cost}}")}</table>
            </td></tr>
          </table>

          <table width="100%" cellpadding="0" cellspacing="0" style="background:#f7f6f2;border-radius:8px;margin-bottom:24px;overflow:hidden;border:1px solid #e2e0d8;">
            <tr><td style="padding:14px 18px;border-bottom:1px solid #e2e0d8;background:#f0efe9;">
              <p style="margin:0;font-size:10px;font-weight:700;color:#888;text-transform:uppercase;letter-spacing:0.1em;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;">Contact Details</p>
            </td></tr>
            <tr><td style="padding:0 18px;">
              <table width="100%" cellpadding="0" cellspacing="0">${l("Name","{{contact_name}}")}${l("Email","{{contact_email}}")}${l("Phone","{{contact_phone}}")}</table>
            </td></tr>
          </table>

          {{#if is_dry_hire}}
          <table width="100%" cellpadding="0" cellspacing="0" style="background:#fffaf5;border-radius:8px;margin-bottom:24px;overflow:hidden;border:1px solid #f0d8b8;">
            <tr><td style="padding:14px 18px;border-bottom:1px solid #f0d8b8;background:#fdf0e0;">
              <p style="margin:0;font-size:10px;font-weight:700;color:#c07030;text-transform:uppercase;letter-spacing:0.1em;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;">Driver Details (Verification Required)</p>
            </td></tr>
            <tr><td style="padding:0 18px;">
              <table width="100%" cellpadding="0" cellspacing="0">${l("Driver Name","{{driver_name}}")}${l("Date of Birth","{{driver_dob}}")}${l("Licence Number","{{driver_licence_number}}")}${l("Licence Expiry","{{driver_licence_expiry}}")}</table>
            </td></tr>
          </table>
          <p style="font-size:12px;color:#888;margin:0 0 20px;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;">
            ID and licence documents are available in the admin panel.
          </p>
          {{/if is_dry_hire}}

          <table width="100%" cellpadding="0" cellspacing="0" style="margin-top:8px;">
            <tr><td align="center">
              <a href="{{admin_url}}"
                style="display:inline-block;background:#1a2235;color:#ffffff;font-size:14px;font-weight:700;padding:12px 28px;border-radius:6px;text-decoration:none;letter-spacing:-0.01em;">
                View in Admin Panel &rarr;
              </a>
            </td></tr>
          </table>
        </td></tr>

        <tr><td style="padding:20px 36px;border-top:1px solid #e2e0d8;background:#f7f6f2;">
          <p style="margin:0;font-size:12px;color:#aaa;text-align:center;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;">
            This notification was sent automatically by {{site_name}}.<br>
            To change the notification email, visit Admin &rarr; Settings.
          </p>
        </td></tr>

      </table>
    </td></tr>
  </table>
</body>
</html>`,d=`<!DOCTYPE html>
<html lang="en">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0"><title>Updated Quote {{booking_ref}}</title></head>
<body style="margin:0;padding:0;background:#f0efe9;">
  <table width="100%" cellpadding="0" cellspacing="0" style="background:#f0efe9;padding:40px 20px;">
    <tr><td align="center">
      <table width="600" cellpadding="0" cellspacing="0" style="background:#ffffff;border-radius:12px;overflow:hidden;border:1px solid #e2e0d8;">
        <tr>
          <td style="background:#1a2235;padding:28px 36px;">
            <table width="100%" cellpadding="0" cellspacing="0"><tr>
              <td>
                <span style="display:inline-block;background:#d4570a;color:#fff;font-weight:800;font-size:13px;padding:4px 8px;border-radius:4px;">&nbsp;A&nbsp;</span>
                <span style="color:#fff;font-weight:700;font-size:15px;margin-left:8px;vertical-align:middle;">{{site_name}}</span>
              </td>
              <td align="right">
                <p style="color:rgba(255,255,255,0.4);font-size:11px;margin:0;text-transform:uppercase;letter-spacing:0.08em;">Updated Quote</p>
                <p style="color:#d4570a;font-size:22px;font-weight:700;margin:4px 0 0 0;font-family:monospace;">{{booking_ref}}</p>
              </td>
            </tr></table>
          </td>
        </tr>
        <tr><td style="padding:32px 36px;">
          <p style="margin:0 0 16px;font-size:15px;color:#1a1a1a;">Hi <strong>{{contact_name}}</strong>,</p>
          <p style="margin:0 0 24px;font-size:14px;color:#555;line-height:1.65;">
            We've updated the pricing for your <strong>{{hire_type}}</strong> booking for the <strong>{{vehicle_name}}</strong>. Please find your updated quote below.
          </p>
          {{#if note}}
          <div style="background:#fffaf5;border:1px solid #f0d8b8;border-radius:8px;padding:16px 20px;margin-bottom:24px;">
            <p style="margin:0 0 6px;font-size:10px;font-weight:700;color:#c07030;text-transform:uppercase;letter-spacing:0.1em;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;">Message from our team</p>
            <p style="margin:0;font-size:14px;color:#3a3a3a;line-height:1.6;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;">{{note}}</p>
          </div>
          {{/if note}}
          <table width="100%" cellpadding="0" cellspacing="0" style="background:#f7f6f2;border-radius:8px;margin-bottom:24px;overflow:hidden;border:1px solid #e2e0d8;">
            <tr><td style="padding:14px 18px;border-bottom:1px solid #e2e0d8;background:#f0efe9;">
              <p style="margin:0;font-size:10px;font-weight:700;color:#888;text-transform:uppercase;letter-spacing:0.1em;">Your Updated Quote</p>
            </td></tr>
            <tr><td style="padding:0 18px;">
              <table width="100%" cellpadding="0" cellspacing="0">${l("Booking Ref","{{booking_ref}}")}${l("Vehicle","{{vehicle_name}}")}${l("Hire Type","{{hire_type}}")}${l("Start Date","{{start_date}}")}${l("End Date","{{end_date}}")}${l("Duration","{{total_days}} days")}${l("Daily Rate","{{daily_rate}}")}${l("Total Cost","{{total_cost}}",!0)}</table>
            </td></tr>
          </table>
          <p style="font-size:13px;color:#888;margin:0 0 24px;line-height:1.6;">
            If you have any questions about this quote, please don't hesitate to get in touch with our team.
          </p>
          <table width="100%" cellpadding="0" cellspacing="0">
            <tr><td align="center">
              <a href="{{site_url}}/vehicles" style="display:inline-block;background:#d4570a;color:#ffffff;font-size:14px;font-weight:700;padding:12px 28px;border-radius:6px;text-decoration:none;">View Our Fleet &rarr;</a>
            </td></tr>
          </table>
        </td></tr>
        <tr><td style="padding:20px 36px;border-top:1px solid #e2e0d8;background:#f7f6f2;">
          <p style="margin:0;font-size:12px;color:#aaa;text-align:center;">This quote was sent by {{site_name}}. Booking reference: {{booking_ref}}</p>
        </td></tr>
      </table>
    </td></tr>
  </table>
</body>
</html>`,p=`<!DOCTYPE html>
<html lang="en">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0"><title>Booking Request Received {{booking_ref}}</title></head>
<body style="margin:0;padding:0;background:#f0efe9;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;">
  <table width="100%" cellpadding="0" cellspacing="0" style="background:#f0efe9;padding:40px 20px;">
    <tr><td align="center">
      <table width="600" cellpadding="0" cellspacing="0" style="background:#ffffff;border-radius:12px;overflow:hidden;border:1px solid #e2e0d8;">
        <tr>
          <td style="background:#1a2235;padding:28px 36px;">
            <table width="100%" cellpadding="0" cellspacing="0"><tr>
              <td>
                <span style="display:inline-block;background:#d4570a;color:#fff;font-weight:800;font-size:13px;padding:4px 8px;border-radius:4px;">A</span>
                <span style="color:#fff;font-weight:700;font-size:15px;margin-left:8px;vertical-align:middle;">{{site_name}}</span>
              </td>
              <td align="right">
                <p style="color:rgba(255,255,255,0.4);font-size:11px;margin:0;text-transform:uppercase;letter-spacing:0.08em;">Booking Request</p>
                <p style="color:#d4570a;font-size:22px;font-weight:700;margin:4px 0 0 0;font-family:monospace;">{{booking_ref}}</p>
              </td>
            </tr></table>
          </td>
        </tr>
        <tr><td style="padding:32px 36px;">
          <p style="margin:0 0 8px;font-size:15px;color:#1a1a1a;">Hi <strong>{{contact_name}}</strong>,</p>
          <p style="margin:0 0 24px;font-size:14px;color:#555;line-height:1.65;">
            Thanks for your booking request. We&apos;ve received your <strong>{{hire_type}}</strong> booking for the <strong>{{vehicle_name}}</strong> and will be in touch to confirm.
          </p>
          <table width="100%" cellpadding="0" cellspacing="0" style="background:#f7f6f2;border-radius:8px;margin-bottom:24px;overflow:hidden;border:1px solid #e2e0d8;">
            <tr><td style="padding:14px 18px;border-bottom:1px solid #e2e0d8;background:#f0efe9;">
              <p style="margin:0;font-size:10px;font-weight:700;color:#888;text-transform:uppercase;letter-spacing:0.1em;">Booking Summary</p>
            </td></tr>
            <tr><td style="padding:0 18px;">
              <table width="100%" cellpadding="0" cellspacing="0">${l("Reference","{{booking_ref}}")}${l("Vehicle","{{vehicle_name}}")}${l("Hire Type","{{hire_type}}")}${l("Start Date","{{start_date}}")}${l("End Date","{{end_date}}")}${l("Duration","{{total_days}} days")}</table>
            </td></tr>
          </table>
          <p style="font-size:13px;color:#888;margin:0;line-height:1.6;">
            If you have any questions, please don&apos;t hesitate to contact us. We look forward to hearing from you.
          </p>
        </td></tr>
        <tr><td style="padding:20px 36px;border-top:1px solid #e2e0d8;background:#f7f6f2;">
          <p style="margin:0;font-size:12px;color:#aaa;text-align:center;">This confirmation was sent by {{site_name}}. Booking reference: {{booking_ref}}</p>
        </td></tr>
      </table>
    </td></tr>
  </table>
</body>
</html>`,c=`<!DOCTYPE html>
<html lang="en">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0"><title>Booking Confirmed {{booking_ref}}</title></head>
<body style="margin:0;padding:0;background:#f0efe9;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;">
  <table width="100%" cellpadding="0" cellspacing="0" style="background:#f0efe9;padding:40px 20px;">
    <tr><td align="center">
      <table width="600" cellpadding="0" cellspacing="0" style="background:#ffffff;border-radius:12px;overflow:hidden;border:1px solid #e2e0d8;">
        <tr>
          <td style="background:#1a2235;padding:28px 36px;">
            <table width="100%" cellpadding="0" cellspacing="0"><tr>
              <td>
                <span style="display:inline-block;background:#d4570a;color:#fff;font-weight:800;font-size:13px;padding:4px 8px;border-radius:4px;">A</span>
                <span style="color:#fff;font-weight:700;font-size:15px;margin-left:8px;vertical-align:middle;">{{site_name}}</span>
              </td>
              <td align="right">
                <p style="color:rgba(255,255,255,0.4);font-size:11px;margin:0;text-transform:uppercase;letter-spacing:0.08em;">Booking Confirmed</p>
                <p style="color:#d4570a;font-size:22px;font-weight:700;margin:4px 0 0 0;font-family:monospace;">{{booking_ref}}</p>
              </td>
            </tr></table>
          </td>
        </tr>
        <tr><td style="padding:32px 36px;">
          <p style="margin:0 0 8px;font-size:15px;color:#1a1a1a;">Hi <strong>{{contact_name}}</strong>,</p>
          <p style="margin:0 0 24px;font-size:14px;color:#555;line-height:1.65;">
            Great news — your <strong>{{hire_type}}</strong> booking for the <strong>{{vehicle_name}}</strong> is confirmed. We look forward to seeing you on <strong>{{start_date}}</strong>.
          </p>
          <table width="100%" cellpadding="0" cellspacing="0" style="background:#f7f6f2;border-radius:8px;margin-bottom:24px;overflow:hidden;border:1px solid #e2e0d8;">
            <tr><td style="padding:14px 18px;border-bottom:1px solid #e2e0d8;background:#f0efe9;">
              <p style="margin:0;font-size:10px;font-weight:700;color:#888;text-transform:uppercase;letter-spacing:0.1em;">Booking Details</p>
            </td></tr>
            <tr><td style="padding:0 18px;">
              <table width="100%" cellpadding="0" cellspacing="0">${l("Reference","{{booking_ref}}")}${l("Vehicle","{{vehicle_name}}")}${l("Hire Type","{{hire_type}}")}${l("Start Date","{{start_date}}")}${l("End Date","{{end_date}}")}${l("Duration","{{total_days}} days")}${l("Daily Rate","{{daily_rate}}")}${l("Total Cost","{{total_cost}}",!0)}</table>
            </td></tr>
          </table>
          <p style="font-size:13px;color:#888;margin:0;line-height:1.6;">
            If you need to make any changes or have questions, please get in touch with our team as soon as possible.
          </p>
        </td></tr>
        <tr><td style="padding:20px 36px;border-top:1px solid #e2e0d8;background:#f7f6f2;">
          <p style="margin:0;font-size:12px;color:#aaa;text-align:center;">{{site_name}} \xb7 Booking reference: {{booking_ref}}</p>
        </td></tr>
      </table>
    </td></tr>
  </table>
</body>
</html>`,g={booking_notification:{key:"email_template_booking_notification",label:"Booking Notification (Admin)",description:"Sent to the admin notification email when a new booking is submitted.",default:s},customer_quote:{key:"email_template_customer_quote",label:"Customer Quote",description:"Sent to the customer when you update their quote from the booking detail page.",default:d},booking_received:{key:"email_template_booking_received",label:"Booking Received (Customer)",description:"Sent to the customer immediately when their booking request is submitted.",default:p},booking_confirmed:{key:"email_template_booking_confirmed",label:"Booking Confirmed (Customer + Admin)",description:"Sent to the customer and admin notification email when a booking status is set to confirmed.",default:c},reminder_24hr:{key:"email_template_reminder_24hr",label:"24hr Reminder (Customer + Admin)",description:"Sent the day before the booking start date. Requires cron to be configured.",default:`<!DOCTYPE html>
<html lang="en">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0"><title>Reminder — Your Booking is Tomorrow</title></head>
<body style="margin:0;padding:0;background:#f0efe9;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;">
  <table width="100%" cellpadding="0" cellspacing="0" style="background:#f0efe9;padding:40px 20px;">
    <tr><td align="center">
      <table width="600" cellpadding="0" cellspacing="0" style="background:#ffffff;border-radius:12px;overflow:hidden;border:1px solid #e2e0d8;">
        <tr>
          <td style="background:#1a2235;padding:28px 36px;">
            <table width="100%" cellpadding="0" cellspacing="0"><tr>
              <td>
                <span style="display:inline-block;background:#d4570a;color:#fff;font-weight:800;font-size:13px;padding:4px 8px;border-radius:4px;">A</span>
                <span style="color:#fff;font-weight:700;font-size:15px;margin-left:8px;vertical-align:middle;">{{site_name}}</span>
              </td>
              <td align="right">
                <p style="color:rgba(255,255,255,0.4);font-size:11px;margin:0;text-transform:uppercase;letter-spacing:0.08em;">Booking Reminder</p>
                <p style="color:#d4570a;font-size:22px;font-weight:700;margin:4px 0 0 0;font-family:monospace;">{{booking_ref}}</p>
              </td>
            </tr></table>
          </td>
        </tr>
        <tr><td style="padding:32px 36px;">
          <p style="margin:0 0 8px;font-size:15px;color:#1a1a1a;">Hi <strong>{{contact_name}}</strong>,</p>
          <p style="margin:0 0 24px;font-size:14px;color:#555;line-height:1.65;">
            Just a reminder that your <strong>{{hire_type}}</strong> booking for the <strong>{{vehicle_name}}</strong> is <strong>tomorrow, {{start_date}}</strong>.
          </p>
          <table width="100%" cellpadding="0" cellspacing="0" style="background:#f7f6f2;border-radius:8px;margin-bottom:24px;overflow:hidden;border:1px solid #e2e0d8;">
            <tr><td style="padding:14px 18px;border-bottom:1px solid #e2e0d8;background:#f0efe9;">
              <p style="margin:0;font-size:10px;font-weight:700;color:#888;text-transform:uppercase;letter-spacing:0.1em;">Your Booking</p>
            </td></tr>
            <tr><td style="padding:0 18px;">
              <table width="100%" cellpadding="0" cellspacing="0">${l("Reference","{{booking_ref}}")}${l("Vehicle","{{vehicle_name}}")}${l("Start Date","{{start_date}}")}${l("End Date","{{end_date}}")}${l("Duration","{{total_days}} days")}</table>
            </td></tr>
          </table>
          <p style="font-size:13px;color:#888;margin:0;line-height:1.6;">
            If you have any last-minute questions, please don&apos;t hesitate to contact us.
          </p>
        </td></tr>
        <tr><td style="padding:20px 36px;border-top:1px solid #e2e0d8;background:#f7f6f2;">
          <p style="margin:0;font-size:12px;color:#aaa;text-align:center;">{{site_name}} \xb7 Booking reference: {{booking_ref}}</p>
        </td></tr>
      </table>
    </td></tr>
  </table>
</body>
</html>`},followup:{key:"email_template_followup",label:"Post-trip Follow-up (Customer + Admin)",description:"Sent the day after the booking end date. Requires cron to be configured.",default:`<!DOCTYPE html>
<html lang="en">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0"><title>Thank You — {{booking_ref}}</title></head>
<body style="margin:0;padding:0;background:#f0efe9;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;">
  <table width="100%" cellpadding="0" cellspacing="0" style="background:#f0efe9;padding:40px 20px;">
    <tr><td align="center">
      <table width="600" cellpadding="0" cellspacing="0" style="background:#ffffff;border-radius:12px;overflow:hidden;border:1px solid #e2e0d8;">
        <tr>
          <td style="background:#1a2235;padding:28px 36px;">
            <table width="100%" cellpadding="0" cellspacing="0"><tr>
              <td>
                <span style="display:inline-block;background:#d4570a;color:#fff;font-weight:800;font-size:13px;padding:4px 8px;border-radius:4px;">A</span>
                <span style="color:#fff;font-weight:700;font-size:15px;margin-left:8px;vertical-align:middle;">{{site_name}}</span>
              </td>
              <td align="right">
                <p style="color:rgba(255,255,255,0.4);font-size:11px;margin:0;text-transform:uppercase;letter-spacing:0.08em;">Thank You</p>
                <p style="color:#d4570a;font-size:22px;font-weight:700;margin:4px 0 0 0;font-family:monospace;">{{booking_ref}}</p>
              </td>
            </tr></table>
          </td>
        </tr>
        <tr><td style="padding:32px 36px;">
          <p style="margin:0 0 8px;font-size:15px;color:#1a1a1a;">Hi <strong>{{contact_name}}</strong>,</p>
          <p style="margin:0 0 24px;font-size:14px;color:#555;line-height:1.65;">
            Thank you for choosing <strong>{{site_name}}</strong>. We hope you enjoyed your <strong>{{hire_type}}</strong> experience with the <strong>{{vehicle_name}}</strong>.
          </p>
          <table width="100%" cellpadding="0" cellspacing="0" style="background:#f7f6f2;border-radius:8px;margin-bottom:24px;overflow:hidden;border:1px solid #e2e0d8;">
            <tr><td style="padding:14px 18px;border-bottom:1px solid #e2e0d8;background:#f0efe9;">
              <p style="margin:0;font-size:10px;font-weight:700;color:#888;text-transform:uppercase;letter-spacing:0.1em;">Booking Summary</p>
            </td></tr>
            <tr><td style="padding:0 18px;">
              <table width="100%" cellpadding="0" cellspacing="0">${l("Reference","{{booking_ref}}")}${l("Vehicle","{{vehicle_name}}")}${l("Dates","{{start_date}} — {{end_date}}")}</table>
            </td></tr>
          </table>
          <p style="font-size:13px;color:#555;margin:0 0 24px;line-height:1.6;">
            We&apos;d love to have you back. Browse our fleet whenever you&apos;re planning your next trip.
          </p>
          <table width="100%" cellpadding="0" cellspacing="0">
            <tr><td align="center">
              <a href="{{site_url}}/vehicles" style="display:inline-block;background:#d4570a;color:#ffffff;font-size:14px;font-weight:700;padding:12px 28px;border-radius:6px;text-decoration:none;">View Our Fleet &rarr;</a>
            </td></tr>
          </table>
        </td></tr>
        <tr><td style="padding:20px 36px;border-top:1px solid #e2e0d8;background:#f7f6f2;">
          <p style="margin:0;font-size:12px;color:#aaa;text-align:center;">{{site_name}} \xb7 Booking reference: {{booking_ref}}</p>
        </td></tr>
      </table>
    </td></tr>
  </table>
</body>
</html>`},enquiry_available:{key:"email_template_enquiry_available",label:"Enquiry — Dates Now Available (Customer)",description:'Sent manually from an enquiry when you click "Notify Customer" to inform them their requested dates are now available.',default:`<!DOCTYPE html>
<html lang="en">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0"><title>Good News — Dates Now Available</title></head>
<body style="margin:0;padding:0;background:#f0efe9;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;">
  <table width="100%" cellpadding="0" cellspacing="0" style="background:#f0efe9;padding:40px 20px;">
    <tr><td align="center">
      <table width="600" cellpadding="0" cellspacing="0" style="background:#ffffff;border-radius:12px;overflow:hidden;border:1px solid #e2e0d8;">
        <tr>
          <td style="background:#1a2235;padding:28px 36px;">
            <table width="100%" cellpadding="0" cellspacing="0"><tr>
              <td>
                <span style="display:inline-block;background:#d4570a;color:#fff;font-weight:800;font-size:13px;padding:4px 8px;border-radius:4px;">A</span>
                <span style="color:#fff;font-weight:700;font-size:15px;margin-left:8px;vertical-align:middle;">{{site_name}}</span>
              </td>
              <td align="right">
                <p style="color:rgba(255,255,255,0.4);font-size:11px;margin:0;text-transform:uppercase;letter-spacing:0.08em;">Availability Update</p>
                <p style="color:#d4570a;font-size:22px;font-weight:700;margin:4px 0 0 0;font-family:monospace;">{{booking_ref}}</p>
              </td>
            </tr></table>
          </td>
        </tr>
        <tr><td style="padding:32px 36px;">
          <p style="margin:0 0 8px;font-size:15px;color:#1a1a1a;">Hi <strong>{{contact_name}}</strong>,</p>
          <p style="margin:0 0 24px;font-size:14px;color:#555;line-height:1.65;">
            Great news! The dates you enquired about for the <strong>{{vehicle_name}}</strong> are now available.
            If you&apos;re still interested, head to our website to make a booking before they fill up again.
          </p>
          <table width="100%" cellpadding="0" cellspacing="0" style="background:#f7f6f2;border-radius:8px;margin-bottom:24px;overflow:hidden;border:1px solid #e2e0d8;">
            <tr><td style="padding:14px 18px;border-bottom:1px solid #e2e0d8;background:#f0efe9;">
              <p style="margin:0;font-size:10px;font-weight:700;color:#888;text-transform:uppercase;letter-spacing:0.1em;">Your Enquiry</p>
            </td></tr>
            <tr><td style="padding:0 18px;">
              <table width="100%" cellpadding="0" cellspacing="0">${l("Reference","{{booking_ref}}")}${l("Vehicle","{{vehicle_name}}")}${l("Start Date","{{start_date}}")}${l("End Date","{{end_date}}")}${l("Duration","{{total_days}} days")}</table>
            </td></tr>
          </table>
          <table width="100%" cellpadding="0" cellspacing="0">
            <tr><td align="center">
              <a href="{{site_url}}/vehicles" style="display:inline-block;background:#d4570a;color:#ffffff;font-size:14px;font-weight:700;padding:12px 28px;border-radius:6px;text-decoration:none;">Book Now &rarr;</a>
            </td></tr>
          </table>
        </td></tr>
        <tr><td style="padding:20px 36px;border-top:1px solid #e2e0d8;background:#f7f6f2;">
          <p style="margin:0;font-size:12px;color:#aaa;text-align:center;">{{site_name}} \xb7 Enquiry reference: {{booking_ref}}</p>
        </td></tr>
      </table>
    </td></tr>
  </table>
</body>
</html>`}};function f({title:e,description:t,children:a}){return(0,i.jsxs)("div",{className:"bg-white border border-border rounded-xl overflow-hidden",children:[(0,i.jsxs)("div",{className:"px-6 py-4 border-b border-border bg-bg",children:[i.jsx("h3",{className:"font-display font-bold text-[14px]",children:e}),t&&i.jsx("p",{className:"text-[12.5px] text-ink-3 mt-0.5",children:t})]}),i.jsx("div",{className:"px-6 py-5 space-y-4",children:a})]})}function m({label:e,children:t}){return(0,i.jsxs)("div",{className:"flex flex-col gap-1.5",children:[i.jsx("label",{className:"text-[11px] font-semibold text-ink-3 uppercase tracking-wider",children:e}),t]})}function x({initial:e}){let[t,a]=(0,n.useState)("booking_notification"),[l,s]=(0,n.useState)(()=>e[g.booking_notification.key]||g.booking_notification.default),[d,p]=(0,n.useState)(""),[c,x]=(0,n.useState)(!1),b=(0,n.useRef)(null),[u,h]=(0,n.useState)(!1),[y,k]=(0,n.useState)(null),[w,_]=(0,n.useState)(null);function v(e,t){"success"===t?(k(e),_(null)):(_(e),k(null)),setTimeout(()=>{k(null),_(null)},4e3)}let S=(0,n.useCallback)(async(e,t)=>{try{let a=await fetch("/api/admin/settings/email-preview",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({template:e,templateType:t})}),i=await a.json();a.ok&&p(i.html)}catch{}},[]);async function z(){h(!0);try{let e=g[t],a=await fetch("/api/admin/settings",{method:"PUT",headers:{"Content-Type":"application/json"},body:JSON.stringify({[e.key]:l})});if(!a.ok){let e=await a.json();throw Error(e.error??"Save failed")}v("Template saved","success"),x(!1)}catch(e){v(e instanceof Error?e.message:"Save failed","error")}finally{h(!1)}}async function $(){if(confirm("Reset this template to the default? Your customisations will be lost.")){h(!0);try{let e=g[t],a=await fetch("/api/admin/settings",{method:"PUT",headers:{"Content-Type":"application/json"},body:JSON.stringify({[e.key]:""})});if(!a.ok){let e=await a.json();throw Error(e.error??"Reset failed")}s(e.default),x(!1),S(e.default,t),v("Template reset to default","success")}catch(e){v(e instanceof Error?e.message:"Reset failed","error")}finally{h(!1)}}}return(0,i.jsxs)("div",{className:"space-y-6",children:[y&&i.jsx("p",{className:"text-[13px] text-success bg-success-bg border border-success/30 rounded-[6px] px-3 py-2",children:y}),w&&i.jsx("p",{className:"text-[13px] text-red-600 bg-red-50 border border-red-200 rounded-[6px] px-3 py-2",children:w}),(0,i.jsxs)(f,{title:"Email Templates",description:"Customise the HTML for each email type. Use {{placeholder}} variables and {{#if condition}}…{{/if condition}} blocks.",children:[i.jsx(m,{label:"Template",children:i.jsx("select",{className:"w-full border border-border rounded-[6px] px-3 py-2.5 text-[13.5px] text-ink bg-white outline-none focus:border-ink focus:ring-2 focus:ring-ink/5 transition-all",value:t,onChange:t=>(function(t){a(t);let i=g[t],n=e[i.key]||i.default;s(n),x(!1),b.current&&clearTimeout(b.current),S(n,t)})(t.target.value),children:Object.keys(g).map(e=>i.jsx("option",{value:e,children:g[e].label},e))})}),i.jsx("p",{className:"text-[12px] text-ink-4 -mt-1",children:g[t].description}),(0,i.jsxs)("div",{className:"grid grid-cols-1 xl:grid-cols-2 gap-4",children:[(0,i.jsxs)("div",{className:"flex flex-col gap-1.5",children:[i.jsx("label",{className:"text-[11px] font-semibold text-ink-3 uppercase tracking-wider",children:"HTML Editor"}),i.jsx("textarea",{className:"w-full border border-border rounded-[6px] px-3 py-2.5 text-[12px] text-ink bg-white outline-none focus:border-ink focus:ring-2 focus:ring-ink/5 transition-all font-mono resize-none leading-relaxed",style:{height:480},value:l,onChange:e=>{var a;s(a=e.target.value),x(!0),b.current&&clearTimeout(b.current),b.current=setTimeout(()=>S(a,t),600)},spellCheck:!1})]}),(0,i.jsxs)("div",{className:"flex flex-col gap-1.5",children:[(0,i.jsxs)("label",{className:"text-[11px] font-semibold text-ink-3 uppercase tracking-wider flex items-center gap-2",children:["Live Preview ",i.jsx("span",{className:"text-ink-4 normal-case tracking-normal font-normal",children:"(sample data)"})]}),i.jsx("iframe",{srcDoc:d||'<p style="font-family:sans-serif;color:#888;padding:20px;">Loading preview…</p>',title:"Email preview",className:"w-full border border-border rounded-[6px] bg-white",style:{height:480},sandbox:"allow-same-origin"})]})]}),(0,i.jsxs)("details",{className:"group",children:[(0,i.jsxs)("summary",{className:"cursor-pointer text-[12px] font-semibold text-ink-3 hover:text-ink transition-colors select-none list-none flex items-center gap-1.5",children:[i.jsx("span",{className:"text-[10px] group-open:rotate-90 transition-transform inline-block",children:"▶"}),"Available variables & conditionals"]}),(0,i.jsxs)("div",{className:"mt-3 space-y-4",children:[(0,i.jsxs)("div",{children:[i.jsx("p",{className:"text-[11px] font-semibold text-ink-3 uppercase tracking-wider mb-2",children:"Variables"}),i.jsx("div",{className:"grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-1",children:r.map(e=>(0,i.jsxs)("div",{className:"flex items-baseline gap-2 text-[12px]",children:[i.jsx("code",{className:"font-mono text-accent shrink-0",children:`{{${e.name}}}`}),i.jsx("span",{className:"text-ink-3 truncate",children:e.description})]},e.name))})]}),(0,i.jsxs)("div",{children:[i.jsx("p",{className:"text-[11px] font-semibold text-ink-3 uppercase tracking-wider mb-2",children:"Conditionals"}),i.jsx("div",{className:"space-y-1.5",children:o.map(e=>(0,i.jsxs)("div",{className:"text-[12px]",children:[i.jsx("code",{className:"font-mono text-[11px] text-accent",children:`{{#if ${e.name}}}…{{/if ${e.name}}}`}),i.jsx("span",{className:"text-ink-3 ml-2",children:e.description})]},e.name))})]})]})]}),(0,i.jsxs)("div",{className:"flex items-center gap-3 pt-1",children:[i.jsx("button",{onClick:z,disabled:u,className:"bg-accent text-white font-display font-bold text-[13.5px] px-5 py-2 rounded-[6px] hover:bg-accent-dark transition-colors disabled:opacity-50",children:u?"Saving…":c?"Save Template *":"Save Template"}),i.jsx("button",{onClick:$,disabled:u,className:"border border-border text-ink-3 font-medium text-[13px] px-4 py-2 rounded-[6px] hover:border-ink-3 hover:text-ink transition-all disabled:opacity-50",children:"Reset to Default"})]})]})]})}},52187:(e,t,a)=>{"use strict";a.r(t),a.d(t,{default:()=>r,metadata:()=>n});var i=a(19510);let n={title:"Settings"};function r({children:e}){return(0,i.jsxs)("div",{className:"px-4 sm:px-10 py-8 md:py-10 max-w-[780px]",children:[i.jsx("h1",{className:"font-display font-bold text-[26px] tracking-tight mb-1",children:"Settings"}),i.jsx("p",{className:"text-[14px] text-ink-3 mb-8",children:"Configure notifications, branding, and other options."}),e]})}},62043:(e,t,a)=>{"use strict";a.r(t),a.d(t,{default:()=>s,metadata:()=>o,revalidate:()=>l});var i=a(19510),n=a(75748);let r=(0,a(68570).createProxy)(String.raw`C:\github\trakovo\src\app\admin\settings\templates\TemplatesForm.tsx#default`),o={title:"Email Templates"},l=0;async function s(){let e=await (0,n.query)("SELECT `key`, value FROM Setting WHERE `key` IN (?, ?)",["email_template_booking_notification","email_template_customer_quote"]),t={};for(let a of e)t[a.key]=a.value;return i.jsx(r,{initial:t})}}};var t=require("../../../../webpack-runtime.js");t.C(e);var a=e=>t(t.s=e),i=t.X(0,[9276,3785,4471,2048,4446],()=>a(90029));module.exports=i})();